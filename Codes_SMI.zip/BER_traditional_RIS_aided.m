%%
% BER performance of traditional RIS-aided systems
% simulate the scaling law of BER - SNR
clc;clear;
%%
% adjust parameters
M = 1;
N = 120;
NR = 8; ns2 = 64;
Ms = 4;
SNR = -36:2:-26;             %(dB)
legend_text = {'M=1,N=120,Ms=4'};


%%

BER_Xp=zeros(length(SNR),1);
for ii = 1:length(SNR)

rho = 10^(SNR(ii)/10);

times = 1e8/log2(Ms);
numoferrorbits_Xp=0;
for t = 1:times

f=(randn(N,1)+1i*randn(N,1))./sqrt(2);
G=(randn(M,N)+1i*randn(M,N))./sqrt(2);

% beamforming strategy : UNFEQ
v = ones(N,1);
for n = 1:N
RISphasen = 0;
for m = 1:M
    RISphasen = RISphasen + (angle(f(n))+angle(G(m,n)));                   % UNFEQ
end
v(n) = exp(-1i*1/M*RISphasen);
end
V = diag(v);

% generate the primary signal to be transmitted
[Xp_in_bits,Xp,alpha,Xs1,Xs2_in_bits,~] = randomly_generate_Xp_and_Xs(Ms,NR,ns2,N);


% simulate tranmissions and detections
B = G*diag(f)*V;
z = sqrt(1/2) * ( randn(M,1) + 1i*randn(M,1) );
y = sqrt(rho)*B*ones(N,1)*Xp + z;

[set_of_Xp_in_bits,set_of_Xp,set_of_Xs1_in_bits,set_of_Xs1,set_of_Xs2_in_bits,set_of_Xs2] = ...
    generate_the_sets_of_Xp_and_Xs(Ms,NR,ns2,N);


MLvalue=zeros(Ms,1);
for i = 1:Ms

    MLvalue(i) = norm(y - sqrt(rho)*B*ones(N,1)*set_of_Xp(:,i),2)^2;

end
[min_value, min_index] = min(MLvalue(:));
[row, col] = find(MLvalue == min_value);
detec_primarybits = set_of_Xp_in_bits(:,row);


%%
% count the number of errors

numoferrorbits_Xp = numoferrorbits_Xp + nnz(detec_primarybits - Xp_in_bits);
end
BER_Xp(ii) = numoferrorbits_Xp / (times*log2(Ms));
end

% % plot constellation
% scatterplot(y);
% title('composite constellation');
% xlabel('Real part');
% ylabel('Imaginary part');
% grid on;

semilogy(SNR, BER_Xp, 'LineWidth', 2); 


legend(legend_text);

xlabel('\rho'); 
ylabel('BER'); 
title('BER - \rho of traditional RIS-aided systems'); 
grid on;