%%
% Theoretical BER of primary signal detected by ML detector with M = 1
clc;clear;
%%
% adjust parameters
M = 1; N = 120; 
SNR = -36:2:-22;

%%
rho = 10.^(SNR/10);
BER_Xp_theo = 2*qfunc(sqrt(pi^2/32*N^2*rho)) .* (ones(1,length(SNR)) - 1/2*qfunc(sqrt(pi^2/32*N^2*rho)));

%%
semilogy(SNR, BER_Xp_theo, 'LineWidth', 2); 
xlabel('\rho(dB)'); 
ylabel('BER'); 
title('Theoretical BER of primary signal with M = 1'); 
grid on;