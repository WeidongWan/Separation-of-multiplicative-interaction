%% 
% simulate transmission and ML detection
clc;clear;
%%
% adjust parameters
Ms = 4; NR = 8; ns2 = 64;
SNR = -36:2:-32; 
legend_text = {'Primary signal(Ms=4,NR=8)', 'Secondary signal(index)(Ms=4,NR=8)'};
N = 120; M = 125;

%%
% generate primary signal and secondary signal

Lsb = floor(log2(nchoosek(NR,NR/2)));
ns1 = 2^Lsb;

                                                           
BER_Xp=zeros(length(SNR),1);BER_Xs=zeros(length(SNR),1);
for ksnr = 1:length(SNR)
    rho = 10^(SNR(ksnr)/10);
times = 1e8/log2(min(Ms,ns1));
numoferrorbits_Xp=0;numoferrorbits_Xs=0;
for t = 1:times
[Xp_in_bits,Xp,alpha,Xs1,Xs2_in_bits,Xs2] = randomly_generate_Xp_and_Xs(Ms,NR,ns2,N);

%%
% generate channels

G = sqrt(1/2) * ( randn(M,N) + 1i*randn(M,N) );
f = sqrt(1/2) * ( randn(N,1) + 1i*randn(N,1) );

V = eye(N);
for n = 1:N
RISphasen = 0;
for m = 1:M
    RISphasen = RISphasen + (angle(f(n))+angle(G(m,n)));                   % UNFEQ
end
V(n,n) = exp(-1i*1/M*RISphasen);
end

B = G*diag(f)*V;
%%
% receive and detect signals

y = sqrt(rho)*B*Xs1*Xp + sqrt(1/2) * ( randn(M,1) + 1i*randn(M,1) );

[set_of_Xp_in_bits,set_of_Xp,set_of_Xs1_in_bits,set_of_Xs1,set_of_Xs2_in_bits,set_of_Xs2] = ...
    generate_the_sets_of_Xp_and_Xs(Ms,NR,ns2,N);

MLvalue=zeros(Ms,ns1);
for i = 1:Ms
    for j = 1:ns1
        MLvalue(i,j) = norm(y - sqrt(rho)*B*set_of_Xs1(:,j)*set_of_Xp(:,i),2)^2;
    end
end
[min_value, min_index] = min(MLvalue(:));
[row, col] = find(MLvalue == min_value);
detec_primarybits = set_of_Xp_in_bits(:,row);
detec_secondarybits = set_of_Xs1_in_bits(:,col);

%%
% count the number of errors

numoferrorbits_Xp = numoferrorbits_Xp + nnz(detec_primarybits - Xp_in_bits);
numoferrorbits_Xs = numoferrorbits_Xs + nnz(detec_secondarybits - alpha);
end
BER_Xp(ksnr) = numoferrorbits_Xp / (times*log2(Ms));
BER_Xs(ksnr) = numoferrorbits_Xs / (times*log2(ns1));
end

semilogy(SNR, BER_Xp, 'LineWidth', 2); 
hold on; 
semilogy(SNR, BER_Xs, 'LineWidth', 2, 'LineStyle', '--'); 



legend(legend_text);

xlabel('SNR (dB)'); 
ylabel('BER'); 
title('BER(simulation) vs. SNR'); 
grid on;