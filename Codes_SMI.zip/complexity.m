%%
%Compare the complexity of different detectors
%number of complex multiplications
clc;clear;
%%
%adjust parameters
N = 120; M = 125;
Ms = 128; color = 'red';
NR = 4:2:12;

%%
Complexity_ML=zeros(1,5);Complexity_SMC=zeros(1,5);Complexity_MMSE=zeros(1,5);Complexity_ZF=zeros(1,5);Complexity_MRC=zeros(1,5);
for nr = 1:length(NR)
    beta = 3*Ms;
    NRnr = NR(nr);
    i = NRnr/2;
    Lsb = floor(log2(nchoosek(NRnr,NRnr/2)));
    ns1 = 2^Lsb;
%ML detector
Complexity_ML(nr) = Ms*ns1*(M*N+M+1);
%SMC detector
Complexity_SMC(nr) = N^2*M+2*N^3/3+2*N^2+N/3+4*Ms+beta*(N/(2*NRnr)*i^2+N^2/2+N*NRnr/2+N/(2*NRnr)*i+N+2*NRnr+2*i-4);
%MMSE detector
Complexity_MMSE(nr) = 2*N^2*M+N^3+N*M+Ms*(2*N+1)+2*ns1*N*(NRnr-1);
%ZF detector
Complexity_ZF(nr) = 2*N^2*M+N^3+N*M+Ms*(2*N+1)+2*ns1*N*(NRnr-1);
%MRC detector
Complexity_MRC(nr) = NRnr*(2*(N/NRnr)^2*M+(N/NRnr)^3)+N*M+Ms*(2*N+1)+2*ns1*N*(NRnr-1);
end

linewidth = 1.5;
figure(1)
semilogy(NR, Complexity_ML,color, 'LineWidth', linewidth, 'Marker', 'p', 'MarkerSize', 8, 'MarkerEdgeColor', color); 
hold on;
semilogy(NR, Complexity_SMC,color, 'LineWidth', linewidth, 'Marker', 'd', 'MarkerSize', 8, 'MarkerEdgeColor', color); 
semilogy(NR, Complexity_MMSE,color, 'LineWidth', linewidth, 'Marker', 's', 'MarkerSize', 11, 'MarkerEdgeColor', color); 
semilogy(NR, Complexity_ZF,color, 'LineWidth', linewidth, 'Marker', '*', 'MarkerSize', 8, 'MarkerEdgeColor', color); 
semilogy(NR, Complexity_MRC,color, 'LineWidth', linewidth, 'Marker', 'o', 'MarkerSize', 8, 'MarkerEdgeColor', color); 

% hold off;
legend('ML','SMC','MMSE','ZF','MRC')
xlim([4, 12]);
% ylim([1e-6, 1]);
xlabel('Number of RIS groups N_R');
ylabel('Number of complex multiplications'); 
grid on