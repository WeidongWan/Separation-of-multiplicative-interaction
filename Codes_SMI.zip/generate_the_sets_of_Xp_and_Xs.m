% generate the sets of Xp and Xs
function [Xp_in_bits,Xp,alpha_Xs1_in_bits,Xs1,Xs2_in_bits,Xs2] = generate_the_sets_of_Xp_and_Xs(Ms,NR,ns2,N)
%%
% primary signal transmitted by the user (Ms-QAM)

% modulation parameters
% Ms = 8;                                                                   % Ms-QAM
number_of_primary_bits = log2(Ms)*1;                                     % the number of signal bits transmitted by the user 
symOrder = 'gray';                                                         % gray code

% bits sequence
x = 0:Ms-1;
Xp_in_bits = zeros(number_of_primary_bits,length(x));                              % primary bit sequence
for j=1:length(x)
for i=1:number_of_primary_bits/log2(Ms)
    Xp_in_bits(log2(Ms)*(i-1)+1:log2(Ms)*i,j) = bitget(x(i,j),log2(Ms):-1:1);
end
end

% implement Ms-QAM
Xp = qammod(x, Ms, symOrder, 'UnitAveragePower', true);

% P=0;
% for i=1:number_of_primary_bits/log2(Ms)
%     P=P+abs(Xp(i))^2;
% end
% P=P/number_of_primary_bits*log2(Ms);

% % plot constellation
% scatterplot(Xp);
% title('Ms-QAM constellation');
% xlabel('Real part');
% ylabel('Imaginary part');
% grid on;
%%
% secondary signal transmitted by the RIS (grouped index modulation)

% N = 120;                                                                   % the number of RIS elements
% NR = 6;                                                                    % the number of groups
Lsb = floor(log2(nchoosek(NR,NR/2)));
ns1 = 2^Lsb;
                                            
zelta = 0:ns1-1;
alpha_Xs1_in_bits = zeros(Lsb,length(zelta));                              % secondary bit sequence
for j=1:length(zelta)
for i=1:1
    alpha_Xs1_in_bits(log2(ns1)*(i-1)+1:log2(ns1)*i,j) = bitget(zelta(i,j),log2(ns1):-1:1);
end
end                                                                        % mapping from alpha to zelta

Rsz = zeros(NR/2,length(zelta));                                           % used for recording the indices of different zeltas
%mapping from zelta to the secondary signal Xs
for z=1:ns1
r=zeros(NR/2,1);r(1)=1;                                                    % the indices of the selected groups
k=zeros(NR/2,1);                                                           % used for recording combination values
for i = 1:NR/2
    K = 0;
    if i > 1
        for ii = 1:i-1
            K = K + k(ii);
        end
    end
    if i > 1
        r(i) = r(i-1)+1;
    end
    while true
    if NR-r(i) < NR/2 - i +1
        k(i) = 0;
    else
        k(i) = nchoosek(NR-r(i),NR/2-i+1);
    end
    if k(i) > zelta(z) - K
        r(i) = r(i) + 1;
    else
        break
    end
    end
end                                                                        % determine the indices of selected groups
Rsz(:,z) = r;
end

Xs1=ones(N,ns1);
for z = 1:ns1
for i = 1:NR/2
    Xs1((Rsz(i,z)-1)*N/NR+1:Rsz(i,z)*N/NR,z)=1i;
end
end
%mapping from zelta to the secondary signal Xs    
%%
% secondary signal transmitted by the RIS (traditional ns2-PSK)

% ns2 = 16;
number_of_secondary_bits2 = log2(ns2)*1;

xs2 = 0:ns2-1;
Xs2_in_bits = zeros(number_of_secondary_bits2,ns2);
for j=1:ns2
for i=1:number_of_secondary_bits2/log2(ns2)
    Xs2_in_bits(log2(ns2)*(i-1)+1:log2(ns2)*i,j) = bitget(xs2(j),log2(ns2):-1:1);
end
end

grayCodes2 = gray2bin(xs2, 'pam', ns2);
theta = 2 * pi * grayCodes2 / ns2;
Xs2=zeros(N,ns2);
for j=1:ns2
Xs2(:,j) = exp(1i * theta(j)) * ones(N,1);
end

% % plot constellation
% scatterplot(Xs2);
% title('MPSK Constellation');
% xlabel('In-phase');
% ylabel('Quadrature');