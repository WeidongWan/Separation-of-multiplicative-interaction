%%
% BER performance of SMI with CGM beamforming
% ML detector is adopted
clc;clear;
%%
% adjust parameters
Ms = 4; NR = 8; ns2 = 64;
N = 120; M = 1;
SNR = -28:2:-22;
txt_name = 'M=1,SMI,ML,CGM,rho = -28,-22dB.txt';

%%
Lsb = floor(log2(nchoosek(NR,NR/2)));
ns1 = 2^Lsb;

BER_Xp=zeros(length(SNR),1);BER_Xs=zeros(length(SNR),1);
ave_receSNR_v=zeros(length(SNR),1);
for ksnr = 1:length(SNR)
    rho = 10^(SNR(ksnr)/10);
    
times = ceil(1e8/log2(min(Ms,ns1)));
numoferrorbits_Xp=zeros(times,1);numoferrorbits_Xs=zeros(times,1);
receSNR_v=zeros(times,1);
parfor t = 1:times
%%
% channels
f=(randn(N,1)+1i*randn(N,1))./sqrt(2);
G=(randn(M,N)+1i*randn(M,N))./sqrt(2);

%%
% beamforming strategy : channel gain maximization

R=diag(f)'*(G'*G)*diag(f);

Vs = CGM(R,N);

[V,D] = eig(Vs);
[value,num] = max(diag(D));
vs = sqrt(value)*V(:,num);              %vs=v*Xs1

%%
% generate the primary and secondary signals to be transmitted
[Xp_in_bits,Xp,alpha,Xs1,Xs2_in_bits,Xs2] = randomly_generate_Xp_and_Xs(Ms,NR,ns2,N);

v = vs./Xs1;
V = diag(v);
%%
% the received SNR
receSNR_v(t) = rho*vs'*diag(f)'*(G'*G)*diag(f)*vs;
%%
% simulate tranmissions and detections

B = G*diag(f)*V;
z = sqrt(1/2) * ( randn(M,1) + 1i*randn(M,1) );
y = sqrt(rho)*B*Xs1*Xp + z;


[set_of_Xp_in_bits,set_of_Xp,set_of_Xs1_in_bits,set_of_Xs1,set_of_Xs2_in_bits,set_of_Xs2] = ...
    generate_the_sets_of_Xp_and_Xs(Ms,NR,ns2,N);

MLvalue=zeros(Ms,ns1);
for i = 1:Ms
    for j = 1:ns1
        MLvalue(i,j) = norm(y - sqrt(rho)*B*set_of_Xs1(:,j)*set_of_Xp(:,i),2)^2;     
    end
end
[min_value, min_index] = min(MLvalue(:));
[row, col] = find(MLvalue == min_value);
detec_primarybits = set_of_Xp_in_bits(:,row);
detec_secondarybits = set_of_Xs1_in_bits(:,col);

%%
% count the number of errors

numoferrorbits_Xp(t) =  nnz(detec_primarybits - Xp_in_bits);
numoferrorbits_Xs(t) =  nnz(detec_secondarybits - alpha);

end

BER_Xp(ksnr) = sum(numoferrorbits_Xp) / (times*log2(Ms));
BER_Xs(ksnr) = sum(numoferrorbits_Xs)/ (times*log2(ns1));

ave_receSNR_v(ksnr) = sum(receSNR_v)/times;
end





header = {'\rho(dB)', 'Average received SNR', 'BER_Xp', 'BER_Xs'}; 

fid = fopen(txt_name, 'w'); 
fprintf(fid, '%s\t%s\t%s\t%s\n', header{:}); 
fclose(fid);

dlmwrite(txt_name, [SNR',ave_receSNR_v,BER_Xp,BER_Xs], '-append', 'delimiter', '\t');