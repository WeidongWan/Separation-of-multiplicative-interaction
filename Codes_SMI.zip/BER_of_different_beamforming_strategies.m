%%
% BER performance of different passive beamforming strategies
% ML detector is adopted
clc;clear;
%%
% adjust parameters
Ms = 4; NR = 2; ns2 = 2;
N = 20; M = 2;
SNR = -12:2:-8;
title_text = 'NR = 2,M = 2';

%%
Lsb = floor(log2(nchoosek(NR,NR/2)));
ns1 = 2^Lsb;

BER_Xp1=zeros(length(SNR),1);BER_Xs1=zeros(length(SNR),1);
BER_Xp2=zeros(length(SNR),1);BER_Xs2=zeros(length(SNR),1);
BER_Xp3=zeros(length(SNR),1);BER_Xs3=zeros(length(SNR),1);
ave_receSNR_v1=zeros(length(SNR),1);ave_receSNR_v2=zeros(length(SNR),1);ave_receSNR_v3=zeros(length(SNR),1);
for ksnr = 1:length(SNR)
    rho = 10^(SNR(ksnr)/10);
    
times = 1e8/log2(min(Ms,ns1));
numoferrorbits_Xp1=0;numoferrorbits_Xs1=0;
numoferrorbits_Xp2=0;numoferrorbits_Xs2=0;
numoferrorbits_Xp3=0;numoferrorbits_Xs3=0;
receSNR_v1=0;receSNR_v2=0;receSNR_v3=0;
for t = 1:times
%%
% channels
f=(randn(N,1)+1i*randn(N,1))./sqrt(2);
G=(randn(M,N)+1i*randn(M,N))./sqrt(2);

%%
% beamforming strategy 1: channel gain maximization

R=diag(f)'*(G'*G)*diag(f);

cvx_begin sdp
    variable Vs(N,N) hermitian semidefinite
    maximize(real(trace(R*Vs)))
    subject to
          Vs >= 0;
          diag(Vs) == ones(N,1);
cvx_end

[V,D] = eig(Vs);
[value,num] = max(diag(D));
vs = sqrt(value)*V(:,num);              %vs=v1*Xs1

%%
% beamforming strategy 2: UNFEQ
v2 = ones(N,1);
for n = 1:N
RISphasen = 0;
for m = 1:M
    RISphasen = RISphasen + (angle(f(n))+angle(G(m,n)));                   % UNFEQ
end
v2(n) = exp(-1i*1/M*RISphasen);
end
V2 = diag(v2);

%%
% beamforming strategy 3: random beamforming
v3 = exp(1i*2*pi.*rand(N,1));             
V3 = diag(v3);

%%
% generate the primary and secondary signals to be transmitted
[Xp_in_bits,Xp,alpha,Xs1,Xs2_in_bits,Xs2] = randomly_generate_Xp_and_Xs(Ms,NR,ns2,N);

v1 = vs./Xs1;
V1 = diag(v1);
%%
% compare the received SNR of different strategies
receSNR_v1 = receSNR_v1 + rho*vs'*diag(f)'*(G'*G)*diag(f)*vs;
receSNR_v2 = receSNR_v2 + rho*(V2*Xs1)'*diag(f)'*(G'*G)*diag(f)*(V2*Xs1);
receSNR_v3 = receSNR_v3 + rho*(V3*Xs1)'*diag(f)'*(G'*G)*diag(f)*(V3*Xs1);

%%
% simulate tranmissions and detections

B1 = G*diag(f)*V1; B2 = G*diag(f)*V2; B3 = G*diag(f)*V3;
z = sqrt(1/2) * ( randn(M,1) + 1i*randn(M,1) );
y1 = sqrt(rho)*B1*Xs1*Xp + z;
y2 = sqrt(rho)*B2*Xs1*Xp + z;
y3 = sqrt(rho)*B3*Xs1*Xp + z;

[set_of_Xp_in_bits,set_of_Xp,set_of_Xs1_in_bits,set_of_Xs1,set_of_Xs2_in_bits,set_of_Xs2] = ...
    generate_the_sets_of_Xp_and_Xs(Ms,NR,ns2,N);

MLvalue1=zeros(Ms,ns1);MLvalue2=zeros(Ms,ns1);MLvalue3=zeros(Ms,ns1);
for i = 1:Ms
    for j = 1:ns1
        MLvalue1(i,j) = norm(y1 - sqrt(rho)*B1*set_of_Xs1(:,j)*set_of_Xp(:,i),2)^2;
        MLvalue2(i,j) = norm(y2 - sqrt(rho)*B2*set_of_Xs1(:,j)*set_of_Xp(:,i),2)^2;
        MLvalue3(i,j) = norm(y3 - sqrt(rho)*B3*set_of_Xs1(:,j)*set_of_Xp(:,i),2)^2;
    end
end
[min_value1, min_index1] = min(MLvalue1(:));
[row1, col1] = find(MLvalue1 == min_value1);
detec_primarybits1 = set_of_Xp_in_bits(:,row1);
detec_secondarybits1 = set_of_Xs1_in_bits(:,col1);

[min_value2, min_index2] = min(MLvalue2(:));
[row2, col2] = find(MLvalue2 == min_value2);
detec_primarybits2 = set_of_Xp_in_bits(:,row2);
detec_secondarybits2 = set_of_Xs1_in_bits(:,col2);

[min_value3, min_index3] = min(MLvalue3(:));
[row3, col3] = find(MLvalue3 == min_value3);
detec_primarybits3 = set_of_Xp_in_bits(:,row3);
detec_secondarybits3 = set_of_Xs1_in_bits(:,col3);
%%
% count the number of errors

numoferrorbits_Xp1 = numoferrorbits_Xp1 + nnz(detec_primarybits1 - Xp_in_bits);
numoferrorbits_Xs1 = numoferrorbits_Xs1 + nnz(detec_secondarybits1 - alpha);

numoferrorbits_Xp2 = numoferrorbits_Xp2 + nnz(detec_primarybits2 - Xp_in_bits);
numoferrorbits_Xs2 = numoferrorbits_Xs2 + nnz(detec_secondarybits2 - alpha);

numoferrorbits_Xp3 = numoferrorbits_Xp3 + nnz(detec_primarybits3 - Xp_in_bits);
numoferrorbits_Xs3 = numoferrorbits_Xs3 + nnz(detec_secondarybits3 - alpha);
end
BER_Xp1(ksnr) = numoferrorbits_Xp1 / (times*log2(Ms));
BER_Xs1(ksnr) = numoferrorbits_Xs1/ (times*log2(ns1));
BER_Xp2(ksnr) = numoferrorbits_Xp2 / (times*log2(Ms));
BER_Xs2(ksnr) = numoferrorbits_Xs2/ (times*log2(ns1));
BER_Xp3(ksnr) = numoferrorbits_Xp3 / (times*log2(Ms));
BER_Xs3(ksnr) = numoferrorbits_Xs3/ (times*log2(ns1));
ave_receSNR_v1(ksnr) = receSNR_v1/times;
ave_receSNR_v2(ksnr) = receSNR_v2/times;
ave_receSNR_v3(ksnr) = receSNR_v3/times;
end

linewidth = 1.5;

figure(1)
plot(SNR, ave_receSNR_v1,'k','LineWidth', linewidth, 'Marker', 'v', 'MarkerSize', 8, 'MarkerEdgeColor', 'k'); 
hold on;
plot(SNR, ave_receSNR_v2,'k','LineWidth', linewidth, 'Marker', 'p', 'MarkerSize', 8, 'MarkerEdgeColor', 'k'); 
plot(SNR, ave_receSNR_v3,'k','LineWidth', linewidth, 'Marker', '^', 'MarkerSize', 8, 'MarkerEdgeColor', 'k'); 

hold off;
legend('CGM','fairness','random beamforming')
xlabel('\rho(dB)');
ylabel('Average received SNR'); 
title(title_text); 
grid on

figure(2)
semilogy(SNR, BER_Xp1,'b','LineWidth', linewidth, 'Marker', 'v', 'MarkerSize', 8, 'MarkerEdgeColor', 'b'); 
hold on;
semilogy(SNR, BER_Xs1,'r','LineWidth', linewidth, 'Marker', 'v', 'MarkerSize', 8, 'MarkerEdgeColor', 'r'); 
semilogy(SNR, BER_Xp2,'b','LineWidth', linewidth, 'Marker', 'p', 'MarkerSize', 8, 'MarkerEdgeColor', 'b'); 
semilogy(SNR, BER_Xs2,'r','LineWidth', linewidth, 'Marker', 'p', 'MarkerSize', 8, 'MarkerEdgeColor', 'r'); 
semilogy(SNR, BER_Xp3,'b','LineWidth', linewidth, 'Marker', '^', 'MarkerSize', 8, 'MarkerEdgeColor', 'b'); 
semilogy(SNR, BER_Xs3,'r','LineWidth', linewidth, 'Marker', '^', 'MarkerSize', 8, 'MarkerEdgeColor', 'r'); 

hold off;
legend('pri. sig.,CGM','sec. sig.,CGM',...
    'pri. sig.,fairness','sec. sig.,fairness',...
    'pri. sig.,random beamforming','sec. sig.,random beamforming')
xlabel('\rho(dB)');
ylabel('BER'); 
title(title_text); 
grid on
