% ML detector (theoretical upper bound)
clc;clear;
%%
% adjust parameters 
Ms = 32;                                                                   % Ms-QAM
NR = 6;                                                                    % the number of groups
ns2 = 16;
SNR = 0:2:10;                                                            %rho
legend_text = {'Primary signal(Ms=32,NR=6)', 'Secondary signal(index)(Ms=32,NR=6)'};
N = 120;                                                                   % the number of RIS elements
M = 4;                                                                     %the number of the BS antennas

%%
% primary signal transmitted by the user (Ms-QAM)

% modulation parameters
number_of_primary_bits = log2(Ms)*1;                                     % the number of signal bits transmitted by the user 
symOrder = 'gray';                                                         % gray code

% bits sequence
x = 0:Ms-1;
Xp_in_bits = zeros(number_of_primary_bits,length(x));                              % primary bit sequence
for j=1:length(x)
for i=1:number_of_primary_bits/log2(Ms)
    Xp_in_bits(log2(Ms)*(i-1)+1:log2(Ms)*i,j) = bitget(x(i,j),log2(Ms):-1:1);
end
end

% implement Ms-QAM
Xp = qammod(x, Ms, symOrder, 'UnitAveragePower', true);

% P=0;
% for i=1:number_of_primary_bits/log2(Ms)
%     P=P+abs(Xp(i))^2;
% end
% P=P/number_of_primary_bits*log2(Ms);

% % plot constellation
% scatterplot(Xp);
% title('Ms-QAM constellation');
% xlabel('Real part');
% ylabel('Imaginary part');
% grid on;
%%
% secondary signal transmitted by the RIS (grouped index modulation)

Lsb = floor(log2(nchoosek(NR,NR/2)));
ns1 = 2^Lsb;
                                            
zelta = 0:ns1-1;
alpha_Xs1_in_bits = zeros(Lsb,length(zelta));                              % secondary bit sequence
for j=1:length(zelta)
for i=1:1
    alpha_Xs1_in_bits(log2(ns1)*(i-1)+1:log2(ns1)*i,j) = bitget(zelta(i,j),log2(ns1):-1:1);
end
end                                                                        % mapping from alpha to zelta

Rsz = zeros(NR/2,length(zelta));                                           % used for recording the indices of different zeltas
%mapping from zelta to the secondary signal Xs
for z=1:ns1
r=zeros(NR/2,1);r(1)=1;                                                    % the indices of the selected groups
k=zeros(NR/2,1);                                                           % used for recording combination values
for i = 1:NR/2
    K = 0;
    if i > 1
        for ii = 1:i-1
            K = K + k(ii);
        end
    end
    if i > 1
        r(i) = r(i-1)+1;
    end
    while true
    if NR-r(i) < NR/2 - i +1
        k(i) = 0;
    else
        k(i) = nchoosek(NR-r(i),NR/2-i+1);
    end
    if k(i) > zelta(z) - K
        r(i) = r(i) + 1;
    else
        break
    end
    end
end                                                                        % determine the indices of selected groups
Rsz(:,z) = r;
end

Xs1=ones(N,ns1);
for z = 1:ns1
for i = 1:NR/2
    Xs1((Rsz(i,z)-1)*N/NR+1:Rsz(i,z)*N/NR,z)=1i;
end
end
%mapping from zelta to the secondary signal Xs    
%%
% secondary signal transmitted by the RIS (traditional ns2-PSK)

number_of_secondary_bits2 = log2(ns2)*1;

xs2 = 0:ns2-1;
Xs2_in_bits = zeros(number_of_secondary_bits2,ns2);
for j=1:ns2
for i=1:number_of_secondary_bits2/log2(ns2)
    Xs2_in_bits(log2(ns2)*(i-1)+1:log2(ns2)*i,j) = bitget(xs2(j),log2(ns2):-1:1);
end
end

grayCodes2 = gray2bin(xs2, 'pam', ns2);
theta = 2 * pi * grayCodes2 / ns2;
Xs2=zeros(N,ns2);
for j=1:ns2
Xs2(:,j) = exp(1i * theta(j)) * ones(N,1);
end

% % plot constellation
% scatterplot(Xs2);
% title('MPSK Constellation');
% xlabel('In-phase');
% ylabel('Quadrature');

%%
% ML detector

s=zeros(2^M,M);
s_dec=0:2^M-1;
for j = 1:length(s_dec)
    s(j,1:M)=bitget(s_dec(j),M:-1:1);
end
s(s==0) = -1;                                                              %obtain s1,s2,...,sM                                       

s_tilt=zeros(2^M,1);s_sum=zeros(2^M,1);S=zeros(2^M,M);
for nn = 1:2^M
    s_tilt(nn) = 1;
    s_sum(nn) = 0;
    for i = 1:M
        s_tilt(nn) = s_tilt(nn)*s(nn,i);
        s_sum(nn) = s_sum(nn)+s(nn,i);
    end
    for i = 1:M
        S(nn,i) = pi*s(nn,i)*(1-1/M)-pi/M*(s_sum(nn)-s(nn,i));
    end
end

THETA = @(x) (x > 0) * 1 + (x == 0) * (1/2) + (x < 0) * 0;
u = cell(M,1);
for m = 1:M
    u{m} = @(x) 0;
    for i = 1:2^M
    u{m} = @(x) u{m}(x) + s_tilt(i).*(x-S(i,m)).^(M-1).*THETA(x-S(i,m));
    end
end
f_psi = @(x) (-1)^M/(factorial(M-1)*(2*pi)^M*(-1/M)^(M-1)*(1-1/M)) .* u{1}(x);% take any one of 'u' to form the PDF of \psi_{mn} due to the symmetry of 'u'

% x = linspace(-20, 20, 400);       
% figure;
% plot(x, f_psi(x), 'LineWidth', 2);
% xlabel('x');
% ylabel('f_{\psi}');
% title('PDF of \psi');
% grid on;
E1 = integral(@(x) cos(x) .* f_psi(x), -5, 5);
E2 = integral(@(x) sin(x) .* f_psi(x), -5, 5);
E3 = integral(@(x) cos(x).^2 .* f_psi(x), -5, 5);
E4 = integral(@(x) sin(x).^2 .* f_psi(x), -5, 5);
E5 = integral(@(x) cos(x).* sin(x) .* f_psi(x), -5, 5);

RISmod = 1;                                                                % '1' for grouped index modulation and '2' for traditional ns2-PSK
if RISmod == 1
    ns=ns1;Xs=Xs1;
else if RISmod == 2
        ns=ns2;Xs=Xs2;
    end
end


PeXpub=zeros(length(SNR),1);PeXsub=zeros(length(SNR),1);
for ksnr = 1:length(SNR)
    rho = 10^(SNR(ksnr)/10);
sumPnXp=0;sumPnXs1=0;sumPnXs2=0;
for i = 1:Ms
    for j = 1:ns
        for i_tilt = 1:Ms
            for j_tilt = 1:ns
                if [i,j] == [i_tilt,j_tilt]
                    continue;
                end
                %Xp(i) Xs1(:,j) Xp(i_tilt) Xs1(:,j_tilt)                   % one pair of detection, for example
                X_Re = zeros(N,1);X_Im = zeros(N,1);
                for n = 1:N
                    X_Re(n) = real(Xs(n,j))*real(Xp(i))-imag(Xs(n,j))*imag(Xp(i))...
                    -real(Xs(n,j_tilt))*real(Xp(i_tilt))+imag(Xs(n,j_tilt))*imag(Xp(i_tilt)); % calculate X_Re and X_Im
                    X_Im(n) = real(Xs(n,j))*imag(Xp(i))+imag(Xs(n,j))*real(Xp(i))...
                    -real(Xs(n,j_tilt))*imag(Xp(i_tilt))-imag(Xs(n,j_tilt))*real(Xp(i_tilt));
                end
                sumXRe = 0;sumXIm = 0;sumX2Re = 0;sumX2Im = 0;sumXReXIm = 0;
                for n = 1:N
                    sumXRe = sumXRe + X_Re(n);
                    sumXIm = sumXIm + X_Im(n);
                    sumX2Re = sumX2Re + X_Re(n)^2;
                    sumX2Im = sumX2Im + X_Im(n)^2;
                    sumXReXIm = sumXReXIm + X_Re(n)*X_Im(n);
                end
                ERedm = pi/4*E1*sumXRe - pi/4*E2*sumXIm;
                DRedm = (E3-pi^2/16*E1^2)*sumX2Re + (E4-pi^2/16*E2^2)*sumX2Im + (pi^2/8*E1*E2-2*E5)*sumXReXIm;
                EImdm = pi/4*E1*sumXIm + pi/4*E2*sumXRe;
                DImdm = (E3-pi^2/16*E1^2)*sumX2Im + (E4-pi^2/16*E2^2)*sumX2Re + (2*E5-pi^2/8*E1*E2)*sumXReXIm;
                sigmaRI = (E5-pi^2/16*E1*E2)*(sumX2Re-sumX2Im) + (pi^2/16*(E2^2-E1^2)+E3-E4)*sumXReXIm;
                if abs(ERedm) < 1e-10
                    ERedm = 1e-10;
                end
                if abs(EImdm) < 1e-10
                    EImdm = 1e-10;
                end
                if abs(DRedm) < 1e-10
                    DRedm = 1e-10;
                end
                if abs(DImdm) < 1e-10
                    DImdm = 1e-10;
                end
                if abs(sigmaRI) < 1e-10
                    sigmaRI = 1e-10;
                end
                md = [ERedm;EImdm];
                Kdmdm = [DRedm,sigmaRI;sigmaRI,DImdm];
                MGF_dm2 = @(t) det(eye(2)-2*t*eye(2)*Kdmdm)^(-1/2) * exp(-1/2*md.'*((eye(2)-inv(eye(2)-2*t*eye(2)*Kdmdm))/Kdmdm)*md);
                MGF_Delta = @(t) MGF_dm2(t)^M;
                P_bar = 1/pi * integral(@(t) MGF_Delta(-rho/(4*sin(t)^2)), 0, pi/2, 'ArrayValued', true);
%                 disp([i,j,i_tilt,j_tilt]);
%                 disp(P_bar);
                numXpiitilt = sum(Xp_in_bits(:,i)~=Xp_in_bits(:,i_tilt));
                numXs1jjtilt = sum(alpha_Xs1_in_bits(:,j)~=alpha_Xs1_in_bits(:,j_tilt));
                numXs2jjtilt = sum(Xs2_in_bits(:,j)~=Xs2_in_bits(:,j_tilt));
                sumPnXp = sumPnXp + P_bar*numXpiitilt;
                sumPnXs1 = sumPnXs1 + P_bar*numXs1jjtilt;
                sumPnXs2 = sumPnXs2 + P_bar*numXs2jjtilt;
            end
        end
    end
end

PprimaryMLUB = sumPnXp/(ns*Ms*log2(Ms));
Psecondary1MLUB = sumPnXs1/(ns*Ms*log2(ns));
Psecondary2MLUB = sumPnXs2/(ns*Ms*log2(ns));
PeXpub(ksnr) = PprimaryMLUB;
PeXsub(ksnr) = Psecondary1MLUB;
end


semilogy(SNR, PeXpub, 'LineWidth', 2); 
hold on; 
semilogy(SNR, PeXsub, 'LineWidth', 2, 'LineStyle', '--'); 



legend(legend_text);

xlabel('SNR (dB)'); 
ylabel('BER'); 
title('BER vs. SNR'); 
grid on;