%%
% BER performance of RIS-segmented strategy
% simulate the scaling law of BER - SNR with the optimal N1
clc;clear;
%%
% adjust parameters
M = 1;
N = 120;
NR = 8; ns2 = 64;
Ms = 4;
SNR = -36:2:-32;             %(dB)
legend_text = {'Primary signal(M=1,RIS-seg)', 'Secondary signal(M=1,RIS-seg)'};
N1 = 76;

%%
N2 = N - N1;

BER_Xp=zeros(length(SNR),1);BER_Xs=zeros(length(SNR),1);
for ii = 1:length(SNR)

rho = 10^(SNR(ii)/10);

times = 1e8/log2(min(Ms,ns2));
numoferrorbits_Xp=0;numoferrorbits_Xs=0;
for t = 1:times

f=(randn(N,1)+1i*randn(N,1))./sqrt(2);
G=(randn(M,N)+1i*randn(M,N))./sqrt(2);

% beamforming strategy : UNFEQ
v = ones(N,1);
for n = 1:N
RISphasen = 0;
for m = 1:M
    RISphasen = RISphasen + (angle(f(n))+angle(G(m,n)));                   % UNFEQ
end
v(n) = exp(-1i*1/M*RISphasen);
end
V = diag(v);

% generate the primary and secondary signals to be transmitted
[Xp_in_bits,Xp,alpha,Xs1,Xs2_in_bits,Xs2] = randomly_generate_Xp_and_Xs(Ms,NR,ns2,N);
Xs2t = Xs2;
Xs2(1:N1) = ones(N1,1);
Xs2_segmented = Xs2;
Xs2 = Xs2t;

% simulate tranmissions and detections
B = G*diag(f)*V;
z = sqrt(1/2) * ( randn(M,1) + 1i*randn(M,1) );
y = sqrt(rho)*B*Xs2_segmented*Xp + z;

[set_of_Xp_in_bits,set_of_Xp,set_of_Xs1_in_bits,set_of_Xs1,set_of_Xs2_in_bits,set_of_Xs2] = ...
    generate_the_sets_of_Xp_and_Xs(Ms,NR,ns2,N);

set_of_Xs2(1:N1,:) = ones(N1,ns2);

MLvalue=zeros(Ms,ns2);
for i = 1:Ms
    for j = 1:ns2
        MLvalue(i,j) = norm(y - sqrt(rho)*B*set_of_Xs2(:,j)*set_of_Xp(:,i),2)^2;
    end
end
[min_value, min_index] = min(MLvalue(:));
[row, col] = find(MLvalue == min_value);
detec_primarybits = set_of_Xp_in_bits(:,row);
detec_secondarybits = set_of_Xs2_in_bits(:,col);

%%
% count the number of errors

numoferrorbits_Xp = numoferrorbits_Xp + nnz(detec_primarybits - Xp_in_bits);
numoferrorbits_Xs = numoferrorbits_Xs + nnz(detec_secondarybits - Xs2_in_bits);
end
BER_Xp(ii) = numoferrorbits_Xp / (times*log2(Ms));
BER_Xs(ii) = numoferrorbits_Xs / (times*log2(ns2));
end

% % plot constellation
% scatterplot(y);
% title('composite constellation');
% xlabel('Real part');
% ylabel('Imaginary part');
% grid on;

semilogy(SNR, BER_Xp, 'LineWidth', 2); 
hold on; 
semilogy(SNR, BER_Xs, 'LineWidth', 2, 'LineStyle', '--'); 



legend(legend_text);

xlabel('\rho'); 
ylabel('BER'); 
title('BER - \rho of RIS-segmented strategy'); 
grid on;