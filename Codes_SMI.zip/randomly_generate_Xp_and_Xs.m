% randomly generate the primary signal Xp and the secondary signal Xs
% using grouped index modulation to generate Xs1 and traditional ns2-PSK to
% generate Xs2
function  [Xp_in_bits,Xp,alpha,Xs1,Xs2_in_bits,Xs2] = randomly_generate_Xp_and_Xs(Ms,NR,ns2,N)
%%
% primary signal transmitted by the user (Ms-QAM)

% modulation parameters
% Ms = 16;                                                                   % Ms-QAM
number_of_primary_bits = log2(Ms)*1;                                     % the number of signal bits transmitted by the user 
symOrder = 'gray';                                                         % gray code

% bits sequence
x = randi([0 Ms-1], number_of_primary_bits/log2(Ms), 1);
Xp_in_bits = zeros(number_of_primary_bits,1);                              % primary bit sequence
for i=1:number_of_primary_bits/log2(Ms)
    Xp_in_bits(log2(Ms)*(i-1)+1:log2(Ms)*i,:) = bitget(x(i),log2(Ms):-1:1);
end

% implement Ms-QAM
Xp = qammod(x, Ms, symOrder, 'UnitAveragePower', true);

% P=0;
% for i=1:number_of_primary_bits/log2(Ms)
%     P=P+abs(Xp(i))^2;
% end
% P=P/number_of_primary_bits*log2(Ms);

% % plot constellation
% scatterplot(Xp);
% title('Ms-QAM constellation');
% xlabel('Real part');
% ylabel('Imaginary part');
% grid on;
%%
% secondary signal transmitted by the RIS (grouped index modulation)

% N = 120;                                                                   % the number of RIS elements
% NR = 4;                                                                    % the number of groups
Lsb = floor(log2(nchoosek(NR,NR/2)));
ns1 = 2^Lsb;
alpha = randi([0 1], Lsb, 1);                                              % secondary bit sequence
zelta = bin2dec(strjoin(cellstr(num2str(alpha)), ''));                     % mapping from alpha to zelta

%mapping from zelta to the secondary signal Xs
r=zeros(NR/2,1);r(1)=1;                                                    % the indices of the selected groups
k=zeros(NR/2,1);                                                           % used for recording combination values
for i = 1:NR/2
    K = 0;
    if i > 1
        for ii = 1:i-1
            K = K + k(ii);
        end
    end
    if i > 1
        r(i) = r(i-1)+1;
    end
    while true
    if NR-r(i) < NR/2 - i +1
        k(i) = 0;
    else
        k(i) = nchoosek(NR-r(i),NR/2-i+1);
    end
    if k(i) > zelta - K
        r(i) = r(i) + 1;
    else
        break
    end
    end
end                                                                        % determine the indices of selected groups
Xs1=ones(N,1);
for i = 1:NR/2
    Xs1((r(i)-1)*N/NR+1:r(i)*N/NR)=1i;
end
%mapping from zelta to the secondary signal Xs    
%%
% secondary signal transmitted by the RIS (traditional ns2-PSK)

% ns2 = 4;
number_of_secondary_bits2 = log2(ns2)*1;

xs2 = randi([0 ns2-1], number_of_secondary_bits2/log2(ns2), 1);
Xs2_in_bits = zeros(number_of_secondary_bits2,1);
for i=1:number_of_secondary_bits2/log2(ns2)
    Xs2_in_bits(log2(ns2)*(i-1)+1:log2(ns2)*i,:) = bitget(xs2(i),log2(ns2):-1:1);
end

grayCodes2 = gray2bin(xs2, 'pam', ns2);
theta = 2 * pi * grayCodes2 / ns2;
Xs2 = exp(1i * theta) * ones(N,1);

% % plot constellation
% scatterplot(Xs2);
% title('MPSK Constellation');
% xlabel('In-phase');
% ylabel('Quadrature');

