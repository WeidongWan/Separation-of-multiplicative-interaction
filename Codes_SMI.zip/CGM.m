%%
% channel gain maximization beamforming strategy
% input - R,N
% output - Vs
%%
function  Vs = CGM(R,N)

cvx_begin sdp
    variable Vs(N,N) hermitian semidefinite
    maximize(real(trace(R*Vs)))
    subject to
          Vs >= 0;
          diag(Vs) == ones(N,1);
cvx_end
