%% 
% simulate transmission and Linear detection
clc;clear;
%%
% adjust parameters
Ms = 4; NR = 4; ns2 = 4;
SNR = -30:2:14; 
choose_lineardetector = 3;                                                 % '1' for ZF detector, '2' for MMSE detector and '3' for MRC detector
legend_text = {'Primary signal(MRC,Ms=4,NR=4)', 'Secondary signal(index)(MRC,Ms=4,NR=4)'};
N = 120; M = 125;

%%
% generate primary signal and secondary signal

Lsb = floor(log2(nchoosek(NR,NR/2)));
ns1 = 2^Lsb;


BER_Xp=zeros(length(SNR),1);BER_Xs=zeros(length(SNR),1);
for ksnr = 1:length(SNR)
    rho = 10^(SNR(ksnr)/10);
times = 1e8/log2(min(Ms,ns1));
numoferrorbits_Xp=0;numoferrorbits_Xs=0;
for t = 1:times
[Xp_in_bits,Xp,alpha,Xs1,Xs2_in_bits,Xs2] = randomly_generate_Xp_and_Xs(Ms,NR,ns2,N);

%%
% generate channels

G = sqrt(1/2) * ( randn(M,N) + 1i*randn(M,N) );
f = sqrt(1/2) * ( randn(N,1) + 1i*randn(N,1) );

V = eye(N);
for n = 1:N
RISphasen = 0;
for m = 1:M
    RISphasen = RISphasen + (angle(f(n))+angle(G(m,n)));                   % UNFEQ
end
V(n,n) = exp(-1i*1/M*RISphasen);
end

B = G*diag(f)*V;

%%
% receive and detect signals

y = sqrt(rho)*B*Xs1*Xp + sqrt(1/2) * ( randn(M,1) + 1i*randn(M,1) );

[set_of_Xp_in_bits,set_of_Xp,set_of_Xs1_in_bits,set_of_Xs1,set_of_Xs2_in_bits,set_of_Xs2] = ...
    generate_the_sets_of_Xp_and_Xs(Ms,NR,ns2,N);

T_ZF = (B'*B)\B';
T_MMSE = (B'*B+1/rho*eye(N))\B';
T_MRC = zeros(N,M); B_NR = zeros(M,N/NR,NR);
for nr = 1:NR
    B_NR(:,:,nr) = B(:,N/NR*(nr-1)+1:N/NR*nr);
    T_MRC(N/NR*(nr-1)+1:N/NR*nr,:) = (B_NR(:,:,nr)'*B_NR(:,:,nr))\B_NR(:,:,nr)';
end

y_bar_ZF = T_ZF*y;
y_bar_MMSE = T_MMSE*y;
y_bar_MRC = T_MRC*y;
if choose_lineardetector == 1
    y_bar = y_bar_ZF;
else if choose_lineardetector == 2
        y_bar = y_bar_MMSE;
    else if choose_lineardetector == 3
            y_bar = y_bar_MRC;
        end
    end
end
    
% detect the primary signal Xp
Linearvalue_for_Xp = zeros(Ms,1);
for i = 1:Ms
    summin = 0;
    for n = 1:N
    summin = summin + min(abs(sqrt(rho)*set_of_Xp(:,i)-y_bar(n)),abs(sqrt(rho)*1i*set_of_Xp(:,i)-y_bar(n)));
    end
    Linearvalue_for_Xp(i) = summin;
end
min_index_Xp = find(Linearvalue_for_Xp == min(Linearvalue_for_Xp));
detec_primarybits = set_of_Xp_in_bits(:,min_index_Xp);
% detect the primary signal Xp

% detect the secondary signal Xs
Linearvalue_for_Xs = zeros(ns1,1);
for i = 1:ns1
    sumnr = 0;
    for nri = 1:NR-1
        for nrj = 2:NR
            if nri >= nrj
                continue;
            end
            sumnri = 0;
            for n = (nri-1)*N/NR+1:nri*N/NR
                sumnri = sumnri + angle(set_of_Xs1(n,i)/y_bar(n));
            end
            sumnrj = 0;
            for n = (nrj-1)*N/NR+1:nrj*N/NR
                sumnrj = sumnrj + angle(set_of_Xs1(n,i)/y_bar(n));
            end
            sumnr = sumnr + abs(NR/N*(sumnri-sumnrj));
        end
    end
    Linearvalue_for_Xs(i) = sumnr;
end
min_index_Xs = find(Linearvalue_for_Xs == min(Linearvalue_for_Xs));
detec_secondarybits = set_of_Xs1_in_bits(:,min_index_Xs);
% detect the secondary signal Xs

%%
% count the number of errors

numoferrorbits_Xp = numoferrorbits_Xp + nnz(detec_primarybits - Xp_in_bits);
numoferrorbits_Xs = numoferrorbits_Xs + nnz(detec_secondarybits - alpha);
end
BER_Xp(ksnr) = numoferrorbits_Xp / (times*log2(Ms));
BER_Xs(ksnr) = numoferrorbits_Xs / (times*log2(ns1));
end

semilogy(SNR, BER_Xp, 'LineWidth', 2); 
hold on; 
semilogy(SNR, BER_Xs, 'LineWidth', 2, 'LineStyle', '--'); 



legend(legend_text);

xlabel('SNR (dB)'); 
ylabel('BER'); 
title('BER(simulation) vs. SNR'); 
grid on;