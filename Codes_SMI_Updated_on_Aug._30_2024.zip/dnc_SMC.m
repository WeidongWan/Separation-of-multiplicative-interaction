%% 
% simulate transmission and SMC detection when both direct and cascaded links are not blocked.
clc;clear;
%%
% adjust parameters
Ms = 16; NR = 6; ns2 = 16;
SNR = -30:2:-6; 
legend_text = ...
    {'Primary signal(SMC,Ms=16,NR=6,\beta=3Ms)', 'Secondary signal(index)(SMC,Ms=16,NR=6,\beta=3Ms)'};
N = 120; M = 125;
beta = 3*Ms;

%%
% generate primary signal and secondary signal

Lsb = floor(log2(nchoosek(NR,NR/2)));
ns1 = 2^Lsb;



BER_Xp=zeros(length(SNR),1);BER_Xs=zeros(length(SNR),1);
for ksnr = 1:length(SNR)
    rho = 10^(SNR(ksnr)/10);
times = 1e8/log2(min(Ms,ns1));
numoferrorbits_Xp=0;numoferrorbits_Xs=0;
for t = 1:times
[Xp_in_bits,Xp,Xs1_in_bits,Xs1,Xs2_in_bits,Xs2] = randomly_generate_Xp_and_Xs(Ms,NR,ns2,N);


%%
% generate channels

G = sqrt(1/2) * ( randn(M,N) + 1i*randn(M,N) );
f = sqrt(1/2) * ( randn(N,1) + 1i*randn(N,1) );
h = sqrt(1/2) * ( randn(M,1) + 1i*randn(M,1) );
mag_G = abs(G); mag_G_sumM = sum(mag_G,1);
mag_h = abs(h);

V = eye(N);
for n = 1:N
RISphasen = 0;
for m = 1:M
    RISphasen = RISphasen + ...
        (mag_h(m)/sum(mag_h)*angle(h(m))-mag_G(m,n)/mag_G_sumM(1,n)*(angle(f(n))+angle(G(m,n))));
end
V(n,n) = exp(1i*RISphasen);
end

B = G*diag(f)*V;

%%
% receive and detect signals
y = sqrt(rho)*h*Xp + sqrt(rho)*B*Xs1*Xp + sqrt(1/2) * ( randn(M,1) + 1i*randn(M,1) );

[set_of_Xp_in_bits,set_of_Xp,set_of_Xs1_in_bits,set_of_Xs1,set_of_Xs2_in_bits,set_of_Xs2] = ...
    generate_the_sets_of_Xp_and_Xs(Ms,NR,ns2,N);

H = [B,h];

Omega = H'*H;
y_bar = Omega^(-1/2)*H'*y;

%QL decomposition
Omega_ph = Omega^(1/2);
[Q,R]= qr ( inv(Omega_ph' ) ); 
L = inv(R)';
%QL decomposition

y_bar_bar = Q'*y_bar;
set_of_Xs1_single_entry = [1,1i];

Post_PXs1Xpybb1 = zeros(Ms,2);
for i = 1:Ms
    for j = 1:2
    PXs1Xp = 1/(2*Ms);
    Likelihood_p_ybb1Xs1Xp = ...
        1/pi*exp(-abs(y_bar_bar(1)-sqrt(rho)*set_of_Xp(i)*L(1,1)*set_of_Xs1_single_entry(j))^2);
    Post_PXs1Xpybb1(i,j) = Likelihood_p_ybb1Xs1Xp * PXs1Xp;
    end
end

max_values = maxk(Post_PXs1Xpybb1(:), beta);
[row, col] = find(ismember(Post_PXs1Xpybb1, max_values));
beta = length(row);

Post_PXs2Xpybb2 = zeros(beta,1);
for b = 1:beta
Likelihood_p_ybb2Xs2Xp = ...
    1/pi*exp(-abs(y_bar_bar(2)-sqrt(rho)*L(2,1)*set_of_Xp(row(b))*set_of_Xs1_single_entry(col(b))-sqrt(rho)*L(2,2)*set_of_Xp(row(b))*set_of_Xs1_single_entry(col(b)))^2);
Post_PXs2Xpybb2(b) =...
    Post_PXs1Xpybb1(row(b),col(b)) * Likelihood_p_ybb2Xs2Xp * 1;
end

Post_PXsnXpybbn = Post_PXs2Xpybb2;
for n = 3:N/NR
for b = 1:beta
sum_before_n = 0;
for i = 1:n-1
    sum_before_n = ...
        sum_before_n + L(n,i)*set_of_Xp(row(b))*set_of_Xs1_single_entry(col(b));
end
Likelihood_p_ybbnXsnXp = ...
    1/pi*exp(-abs(y_bar_bar(n)-sqrt(rho)*sum_before_n-sqrt(rho)*L(n,n)*set_of_Xp(row(b))*set_of_Xs1_single_entry(col(b)))^2);
Post_PXsnXpybbn(b) = Post_PXsnXpybbn(b) * Likelihood_p_ybbnXsnXp * 1;
end
end

Post_PXsNdivNRadd1XpybbNdivNRadd1 = zeros(3*beta,1);
for ind = 1:3
for b = 1:beta
    if ind == 1
    XsNdivNRadd1Xp = set_of_Xp(row(b))*set_of_Xs1_single_entry(col(b));
    Prior_PXsNdivNRadd1Xp = (NR-2)/(2*(NR-1));
    else if ind == 2
    XsNdivNRadd1Xp = 1i*set_of_Xp(row(b))*set_of_Xs1_single_entry(col(b));
    Prior_PXsNdivNRadd1Xp = NR/(4*(NR-1));
        else if ind == 3
    XsNdivNRadd1Xp = -1i*set_of_Xp(row(b))*set_of_Xs1_single_entry(col(b));
    Prior_PXsNdivNRadd1Xp = NR/(4*(NR-1));
            end
        end
    end
sum_before_n = 0;
for i = 1:N/NR
    sum_before_n = ...
        sum_before_n + L(N/NR+1,i)*set_of_Xp(row(b))*set_of_Xs1_single_entry(col(b));
end
Likelihood_p_ybbNdivNRadd1XsNdivNRadd1Xp = ...
    1/pi*exp(-abs(y_bar_bar(N/NR+1)-sqrt(rho)*sum_before_n-sqrt(rho)*L(N/NR+1,N/NR+1)*XsNdivNRadd1Xp)^2);
Post_PXsNdivNRadd1XpybbNdivNRadd1((ind-1)*beta+b) = ...
    Post_PXsnXpybbn(b) * Likelihood_p_ybbNdivNRadd1XsNdivNRadd1Xp * Prior_PXsNdivNRadd1Xp;
end
end

[sorted_values, sorted_indices] = sort(Post_PXsNdivNRadd1XpybbNdivNRadd1, 'descend');
max_indices = sorted_indices(1:beta);

NR1=zeros(beta,1);NR2=zeros(beta,1);
Post_PXmNdivNRadd2ybbNdivNRadd2 = zeros(beta,1);
for b = 1:beta
    if mod(max_indices(b),beta) == 0
        if max_indices(b)/beta == 1
            NR1(b) = set_of_Xp(row(beta))*set_of_Xs1_single_entry(col(beta));
            NR2(b) = set_of_Xp(row(beta))*set_of_Xs1_single_entry(col(beta));
        else if max_indices(b)/beta == 2
                NR1(b) = set_of_Xp(row(beta))*set_of_Xs1_single_entry(col(beta));
                NR2(b) = 1i*set_of_Xp(row(beta))*set_of_Xs1_single_entry(col(beta));
            else if max_indices(b)/beta == 3
                    NR1(b) = set_of_Xp(row(beta))*set_of_Xs1_single_entry(col(beta));
                    NR2(b) = -1i*set_of_Xp(row(beta))*set_of_Xs1_single_entry(col(beta));
                end
            end
        end
    else
        be = mod(max_indices(b),beta);
        in = ceil(max_indices(b)/beta);
        if in == 1
            NR1(b) = set_of_Xp(row(be))*set_of_Xs1_single_entry(col(be));
            NR2(b) = set_of_Xp(row(be))*set_of_Xs1_single_entry(col(be));
        else if in == 2
                NR1(b) = set_of_Xp(row(be))*set_of_Xs1_single_entry(col(be));
                NR2(b) = 1i*set_of_Xp(row(be))*set_of_Xs1_single_entry(col(be));
            else if in == 3
                    NR1(b) = set_of_Xp(row(be))*set_of_Xs1_single_entry(col(be));
                    NR2(b) = -1i*set_of_Xp(row(be))*set_of_Xs1_single_entry(col(be));
                end
            end
        end
    end
    
sum_before_NdivNRadd1 = 0;
for i = 1:N/NR
    sum_before_NdivNRadd1 = ...
        sum_before_NdivNRadd1 + L(N/NR+2,i)*NR1(b);
end
sum_before_NdivNRadd1 = sum_before_NdivNRadd1 + L(N/NR+2,N/NR+1)*NR2(b);
Likelihood_p_ybbNdivNRadd2XmNdivNRadd2 = ...
    1/pi*exp(-abs(y_bar_bar(N/NR+2)-sqrt(rho)*sum_before_NdivNRadd1-sqrt(rho)*L(N/NR+2,N/NR+2)*NR2(b))^2);
Post_PXmNdivNRadd2ybbNdivNRadd2(b) = ...
    Post_PXsNdivNRadd1XpybbNdivNRadd1(max_indices(b)) * Likelihood_p_ybbNdivNRadd2XmNdivNRadd2 * 1;
end


Post_PXmnybbn = Post_PXmNdivNRadd2ybbNdivNRadd2;
for n = N/NR+3:2*N/NR
for b = 1:beta

sum_before_n = 0;
for i = 1:N/NR
    sum_before_n = sum_before_n + L(n,i)*NR1(b);
end
for i = N/NR+1:n-1
    sum_before_n = sum_before_n + L(n,i)*NR2(b);
end
Likelihood_p_ybbnXmn = ...
    1/pi*exp(-abs(y_bar_bar(n)-sqrt(rho)*sum_before_n-sqrt(rho)*L(n,n)*NR2(b))^2);
Post_PXmnybbn(b) = Post_PXmnybbn(b) * Likelihood_p_ybbnXmn * 1;
end
end


XmNdivNR_NR = zeros(beta,N);
for i = 1:N/NR
XmNdivNR_NR(:,i) = NR1;
end
for i = N/NR+1:2*N/NR
XmNdivNR_NR(:,i) = NR2;
end
XmNdivNR = zeros(beta,NR);XmNdivNR(:,1)=NR1;XmNdivNR(:,2)=NR2;
for n = 2*N/NR+1:N
    Post_PXmnybbn_extend = zeros(beta,3);                              %The next iteration can expand up to 3 results for each 'b'
for b = 1:beta
    if mod(n,N/NR) == 1
        i = floor(n/(N/NR));
        sum_before_n = 0;
        for iii = 1:i
        for ii = (iii-1)*N/NR+1:iii*N/NR
            sum_before_n = sum_before_n + L(n,ii) * XmNdivNR(b,iii);
        end
        end
        if numel(unique(XmNdivNR(b,1:i))) == 1
            if i < NR/2
                num_of_prior = 3; 
                prior = zeros(num_of_prior,1);Xm = zeros(num_of_prior,1);Likelihood_p_n = zeros(num_of_prior,1);
                prior(1) = (nchoosek(NR-(i+1), NR/2)+nchoosek(NR-(i+1), NR/2-(i+1)))/(nchoosek(NR-i, NR/2)+nchoosek(NR-i, NR/2-i));
                prior(2) = nchoosek(NR-(i+1), NR/2-1)/(nchoosek(NR-i, NR/2)+nchoosek(NR-i, NR/2-i));
                prior(3) = nchoosek(NR-(i+1), NR/2-i)/(nchoosek(NR-i, NR/2)+nchoosek(NR-i, NR/2-i));
                Xm(1) = unique(XmNdivNR(b,1:i));
                Xm(2) = 1i*unique(XmNdivNR(b,1:i));
                Xm(3) = -1i*unique(XmNdivNR(b,1:i));
                Likelihood_p_n(1) = ...
                    1/pi*exp(-abs(y_bar_bar(n)-sqrt(rho)*sum_before_n-sqrt(rho)*L(n,n)*Xm(1))^2);
                Likelihood_p_n(2) = ...
                    1/pi*exp(-abs(y_bar_bar(n)-sqrt(rho)*sum_before_n-sqrt(rho)*L(n,n)*Xm(2))^2);
                Likelihood_p_n(3) = ...
                    1/pi*exp(-abs(y_bar_bar(n)-sqrt(rho)*sum_before_n-sqrt(rho)*L(n,n)*Xm(3))^2);
                Post_PXmnybbn_extend(b,1) = Post_PXmnybbn(b) * Likelihood_p_n(1) * prior(1);
                Post_PXmnybbn_extend(b,2) = Post_PXmnybbn(b) * Likelihood_p_n(2) * prior(2);
                Post_PXmnybbn_extend(b,3) = Post_PXmnybbn(b) * Likelihood_p_n(3) * prior(3);               
            else if i == NR/2
                num_of_prior = 2;
                prior = zeros(num_of_prior,1);Xm = zeros(num_of_prior,1);Likelihood_p_n = zeros(num_of_prior,1);
                prior(1) = 1/2;
                prior(2) = 1/2;
                Xm(1) = 1i*unique(XmNdivNR(b,1:i));
                Xm(2) = -1i*unique(XmNdivNR(b,1:i));
                Likelihood_p_n(1) = ...
                    1/pi*exp(-abs(y_bar_bar(n)-sqrt(rho)*sum_before_n-sqrt(rho)*L(n,n)*Xm(1))^2);
                Likelihood_p_n(2) = ...
                    1/pi*exp(-abs(y_bar_bar(n)-sqrt(rho)*sum_before_n-sqrt(rho)*L(n,n)*Xm(2))^2);
                Post_PXmnybbn_extend(b,1) = Post_PXmnybbn(b) * Likelihood_p_n(1) * prior(1);
                Post_PXmnybbn_extend(b,2) = Post_PXmnybbn(b) * Likelihood_p_n(2) * prior(2);
            else if i > NR/2
                prior = 0;
                end
                end
            end
        else
            unique_values = unique(XmNdivNR(b,1:i));
            if angle(unique_values(1)/unique_values(2)) == pi/2
                imagemulXu = unique_values(1);
                Xu = unique_values(2);
            else if angle(unique_values(1)/unique_values(2)) == -pi/2
                    imagemulXu = unique_values(2);
                    Xu = unique_values(1);
                end
            end
            n0 = sum(XmNdivNR(b,1:i) == imagemulXu);
            if n0 > NR/2
                prior = 0;
            end
            if n0 <= NR/2
                if i <= NR/2
                    num_of_prior = 2;Xm = zeros(num_of_prior,1);Likelihood_p_n = zeros(num_of_prior,1);
                    prior = zeros(num_of_prior,1);
                    prior(1) = nchoosek(NR-(i+1),NR/2-n0)/nchoosek(NR-i,NR/2-n0);
                    prior(2) = nchoosek(NR-(i+1),NR/2-(n0+1))/nchoosek(NR-i,NR/2-n0);
                    Xm(1) = Xu;
                    Xm(2) = imagemulXu;
                    Likelihood_p_n(1) = ...
                    1/pi*exp(-abs(y_bar_bar(n)-sqrt(rho)*sum_before_n-sqrt(rho)*L(n,n)*Xm(1))^2);
                    Likelihood_p_n(2) = ...
                    1/pi*exp(-abs(y_bar_bar(n)-sqrt(rho)*sum_before_n-sqrt(rho)*L(n,n)*Xm(2))^2);
                    Post_PXmnybbn_extend(b,1) = Post_PXmnybbn(b) * Likelihood_p_n(1) * prior(1);
                    Post_PXmnybbn_extend(b,2) = Post_PXmnybbn(b) * Likelihood_p_n(2) * prior(2);
                else if i > NR/2
                        if n0 < i-NR/2
                            prior = 0;
                        else if (n0 > i-NR/2) & (n0 < NR/2)
                                num_of_prior = 2;Xm = zeros(num_of_prior,1);Likelihood_p_n = zeros(num_of_prior,1);
                                prior = zeros(num_of_prior,1);
                                prior(1) = ...
                                    nchoosek(NR-(i+1),NR/2-n0)/nchoosek(NR-i,NR/2-n0);
                                prior(2) = ...
                                    nchoosek(NR-(i+1),NR/2-(n0+1))/nchoosek(NR-i,NR/2-n0);
                                Xm(1) = Xu;
                                Xm(2) = imagemulXu;
                                Likelihood_p_n(1) = ...
                                1/pi*exp(-abs(y_bar_bar(n)-sqrt(rho)*sum_before_n-sqrt(rho)*L(n,n)*Xm(1))^2);
                                Likelihood_p_n(2) = ...
                                1/pi*exp(-abs(y_bar_bar(n)-sqrt(rho)*sum_before_n-sqrt(rho)*L(n,n)*Xm(2))^2);
                                Post_PXmnybbn_extend(b,1) = Post_PXmnybbn(b) * Likelihood_p_n(1) * prior(1);
                                Post_PXmnybbn_extend(b,2) = Post_PXmnybbn(b) * Likelihood_p_n(2) * prior(2);                   
                            else if n0 == NR/2
                                    prior = 1;Xm = Xu;
                                    Likelihood_p_n = ...
                                    1/pi*exp(-abs(y_bar_bar(n)-sqrt(rho)*sum_before_n-sqrt(rho)*L(n,n)*Xm)^2);
                                    Post_PXmnybbn_extend(b,1) = Post_PXmnybbn(b) * Likelihood_p_n * prior;
                                else if n0 == i-NR/2
                                        prior = 1;Xm = imagemulXu;
                                        Likelihood_p_n = ...
                                        1/pi*exp(-abs(y_bar_bar(n)-sqrt(rho)*sum_before_n-sqrt(rho)*L(n,n)*Xm)^2);
                                        Post_PXmnybbn_extend(b,1) = Post_PXmnybbn(b) * Likelihood_p_n * prior;
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    else
        prior = 1;
        sum_before_n = 0;
        for iiii = 1:n-1
            sum_before_n = sum_before_n + L(n,iiii) * XmNdivNR_NR(b,iiii);
        end
        Likelihood_p_n = ...
        1/pi*exp(-abs(y_bar_bar(n)-sqrt(rho)*sum_before_n-sqrt(rho)*L(n,n)*XmNdivNR_NR(b,n-1))^2);
        Post_PXmnybbn(b) = Post_PXmnybbn(b) * Likelihood_p_n * prior;
    end
end

if mod(n,N/NR) == 1
        i = floor(n/(N/NR));
[k_max_values, k_max_indices] = maxk(Post_PXmnybbn_extend(:), beta);
[max_rows, max_cols] = ind2sub(size(Post_PXmnybbn_extend), k_max_indices);
Post_PXmnybbn = reshape(k_max_values, [1, beta]);

A = zeros(beta,n);
for mr = 1:beta
A(mr,1:n-1) = XmNdivNR_NR(max_rows(mr),1:n-1);
if max_cols(mr) == 3
A(mr,n) = -1i*XmNdivNR_NR(max_rows(mr),n-1);
else if max_cols(mr) == 2
        if numel(unique(XmNdivNR(max_rows(mr),1:i))) == 1
            if i < NR/2
                A(mr,n) = 1i*unique(XmNdivNR(max_rows(mr),1:i));
            else if i == NR/2
                    A(mr,n) = -1i*unique(XmNdivNR(max_rows(mr),1:i));
                end
            end
        else
            unique_values = unique(XmNdivNR(max_rows(mr),1:i));
            if angle(unique_values(1)/unique_values(2)) == pi/2
                imagemulXu = unique_values(1);
                Xu = unique_values(2);
            else if angle(unique_values(1)/unique_values(2)) == -pi/2
                    imagemulXu = unique_values(2);
                    Xu = unique_values(1);
                end
            end
            n0 = sum(XmNdivNR(max_rows(mr),1:i) == imagemulXu);
            if n0 <= NR/2
                if i <= NR/2
                    A(mr,n) = imagemulXu;
                else if i > NR/2
                    A(mr,n) = imagemulXu;
                    end
                end
            end
        end
    else if max_cols(mr) == 1
            if numel(unique(XmNdivNR(max_rows(mr),1:i))) == 1
                if i < NR/2
                    A(mr,n) = unique(XmNdivNR(max_rows(mr),1:i));
                else if i == NR/2
                        A(mr,n) = 1i*unique(XmNdivNR(max_rows(mr),1:i));
                    end
                end
            else
                unique_values = unique(XmNdivNR(max_rows(mr),1:i));
                if angle(unique_values(1)/unique_values(2)) == pi/2
                    imagemulXu = unique_values(1);
                    Xu = unique_values(2);
                else if angle(unique_values(1)/unique_values(2)) == -pi/2
                    imagemulXu = unique_values(2);
                    Xu = unique_values(1);
                    end
                end
                n0 = sum(XmNdivNR(max_rows(mr),1:i) == imagemulXu);
                if n0 <= NR/2
                    if i <= NR/2
                        A(mr,n) = Xu;
                        else if i > NR/2
                                if (n0 > i-NR/2) & (n0 < NR/2)
                                    A(mr,n) = Xu;
                                else if n0 == NR/2
                                        A(mr,n) = Xu;
                                    else if n0 == i-NR/2
                                            A(mr,n) = imagemulXu;
                                        end
                                    end
                                end
                            end
                    end
                end
            end
        end
    end
end

end
XmNdivNR_NR = A;

for mr_further = 1:beta
    if  numel(unique(XmNdivNR_NR(mr_further,1:n))) == 2
        num_detected_group = floor(n/(N/NR));
        phase_group = zeros(num_detected_group+1,1);
        for index_detected_group = 1:num_detected_group
            phase_group(index_detected_group) = ...
                XmNdivNR_NR(mr_further,index_detected_group * N/NR);
        end
        phase_group(num_detected_group+1) = XmNdivNR_NR(mr_further,n);
        
        Xpbn = unique(XmNdivNR_NR(mr_further,1:n));
        if angle(Xpbn(1)/Xpbn(2)) == pi/2
            ortho_Xp = Xpbn(1);
        else if angle(Xpbn(1)/Xpbn(2)) == -pi/2
                ortho_Xp = Xpbn(2);
            end
        end
        part_indices = find(phase_group == ortho_Xp);
        zelta_b_k = 0;
        for r = 1:length(part_indices)
            if NR/2-r+1 > NR-part_indices(r)
                addzelta_b_k = 0;
            else
                addzelta_b_k = nchoosek(NR-part_indices(r),NR/2-r+1);
            end
            zelta_b_k = zelta_b_k + addzelta_b_k;
        end
        if zelta_b_k >= ns1
            Post_PXmnybbn(mr_further) = 0;
        end
    end
end

else
    [Post_PXmnybbn, sort_indices] = sort(Post_PXmnybbn, 'descend');

    
    B = zeros(beta,n);
    for ms = 1:beta
    B(ms,n) = XmNdivNR_NR(sort_indices(ms),n-1);
    B(ms,1:n-1) = XmNdivNR_NR(sort_indices(ms),1:n-1);
    end
    XmNdivNR_NR = B;
end

if mod(n,N/NR) == 0
    K = n/(N/NR);
    for ik = 1:K
        XmNdivNR(:,ik) = XmNdivNR_NR(:,ik*(N/NR));
    end                
end
                
                    
            
                    
            
end



% detect the primary signal in b-th sample
Xp_detect = zeros(beta,1);
for sfb = 1:beta
Xp2value = unique(XmNdivNR(sfb,:));
if angle(Xp2value(1)/Xp2value(2)) == pi/2
    Xp_detect(sfb) = Xp2value(2);
else if angle(Xp2value(1)/Xp2value(2)) == -pi/2
        Xp_detect(sfb) = Xp2value(1);
    end
end
end

% The last iteration (The posterior probability is resorted due to the direct link)
sum1toNLnixs1ixp = zeros(beta,1);likelihoodfunc_last = zeros(beta,1);Post_last = zeros(beta,1);
for sfb = 1:beta
    for sfbi = 1:N
        sum1toNLnixs1ixp(sfb) = sum1toNLnixs1ixp(sfb) + ...
            L(N+1,sfbi) * XmNdivNR_NR(sfb,sfbi);
    end
    likelihoodfunc_last(sfb) = ...
        1/pi*exp(-abs(y_bar_bar(N+1)-sqrt(rho)*sum1toNLnixs1ixp(sfb)-sqrt(rho)*L(N+1,N+1)*Xp_detect(sfb))^2);
    Post_last(sfb) = Post_PXmnybbn(sfb) * likelihoodfunc_last(sfb) * 1;
end
[Post_last, sort_indices_Post_last] = sort(Post_last, 'descend');
BB = zeros(beta,N+1);
for sfb = 1:beta
    BB(sfb,N+1) = Xp_detect(sort_indices_Post_last(sfb));
    BB(sfb,1:N) = XmNdivNR_NR(sort_indices_Post_last(sfb),1:N);
end
XmNdivNR_NR = BB;
XmNR = zeros(1,NR);
for iNR = 1:NR
    XmNR(:,iNR) = XmNdivNR_NR(1,iNR*(N/NR));
end
Xp_detect_last = XmNdivNR_NR(1,N+1);



% Convert symbol to bits for both primary and secondary signals
indexXp = find(set_of_Xp == Xp_detect_last);
Xp_detect_in_bits = set_of_Xp_in_bits(:,indexXp);

indices = find(XmNR == 1i*Xp_detect_last);
zelta = 0;
for r = 1:length(indices)
    if NR/2-r+1 > NR-indices(r)
        addzelta = 0;
    else
        addzelta = nchoosek(NR-indices(r),NR/2-r+1);
    end
    zelta = zelta + addzelta;
end
Xs1_detect_in_bits = bitget(zelta,Lsb:-1:1);
% Convert symbol to bits for both primary and secondary signals  

%%
% count the number of errors

numoferrorbits_Xp = numoferrorbits_Xp + nnz(Xp_detect_in_bits - Xp_in_bits);
numoferrorbits_Xs = numoferrorbits_Xs + nnz(Xs1_detect_in_bits' - Xs1_in_bits);
end
BER_Xp(ksnr) = numoferrorbits_Xp / (times*log2(Ms));
BER_Xs(ksnr) = numoferrorbits_Xs / (times*log2(ns1));
end

semilogy(SNR, BER_Xp, 'LineWidth', 2); 
hold on; 
semilogy(SNR, BER_Xs, 'LineWidth', 2, 'LineStyle', '--'); 



legend(legend_text);

xlabel('SNR (dB)'); 
ylabel('BER'); 
title('BER(simulation) vs. SNR'); 
grid on;